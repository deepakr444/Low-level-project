// Get the HTML elements
const sendButton = document.getElementById('send-btn');
const userInput = document.getElementById('user-input');
const chatBox = document.getElementById('chat-box');

// Function to append messages to the chat box
function appendMessage(sender, message) {
    const messageElement = document.createElement('div');
    messageElement.classList.add(sender); // Add 'user' or 'bot' class for styling
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll to the bottom
}

// Function to get the bot's response using fetch
async function getBotResponse(userMessage) {
    appendMessage('user', userMessage); // Display the user's message

    try {
        const response = await fetch('/chatbot', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ prompt: userMessage }) // Send user message to the server
        });

        if (!response.ok) {
            throw new Error(HTTP error! Status: ${response.status});
        }

        try {
            const data = await response.json(); // Parse the response from the server
            const botMessage = data.message; // Get the bot's response
            appendMessage('bot', botMessage); // Display the bot's response
        } catch (error) {
            console.error('Error parsing JSON:', error);
            appendMessage('bot', "Sorry, I couldn't understand the response. Please try again.");
        }

    } catch (error) {
        console.error('Error fetching:', error);
        appendMessage('bot', "Sorry, the server is unavailable right now. Please try again later.");
    }
}

// Event listener for the Send button
sendButton.addEventListener('click', () => {
    const userMessage = userInput.value.trim();
    if (userMessage) {
        getBotResponse(userMessage); // Call function to send the user message
        userInput.value = ''; // Clear the input field after sending the message
    }
});