// Import required packages
const express = require('express');
const { OpenAI } = require('openai');
require('dotenv').config(); // Load environment variables from .env

// Initialize express app
const app = express();
const port = process.env.PORT || 3000; // Use the environment port or default to 3000

// Initialize OpenAI client with the API key from the .env file
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,  // Your OpenAI key will be loaded from .env file
});

// Middleware to parse JSON request bodies
app.use(express.json());

// Define the route for chatbot interaction
app.post('/chatbot', async (req, res) => {
  const { prompt } = req.body; // Get user input from the request body

  try {
    // Call OpenAI API to get a response
    const completion = await openai.chat.completions.create({
      model: 'gpt-4', // You can change this to gpt-3.5-turbo or other models if needed
      messages: [{ role: 'user', content: prompt }],
    });

    // Get the AI response from the OpenAI API
    const botMessage = completion.choices[0].message.content;
    res.json({ message: botMessage }); // Send the bot's response back to the client

  } catch (error) {
    console.error('Error with OpenAI API:', error);
    res.status(500).send({ error: 'Failed to get a response from AI.' }); // Handle errors
  }
});

// Serve static files (your frontend files like HTML, CSS, JS)
app.use(express.static('public')); // Ensure you have a 'public' folder for your frontend files

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`); // Log server running message
});const sendButton = document.getElementById('send-btn');
const userInput = document.getElementById('user-input');
const chatBox = document.getElementById('chat-box');

// Function to append messages to the chat box
function appendMessage(sender, message) {
  const messageElement = document.createElement('div');
  messageElement.classList.add(sender);
  messageElement.textContent = message;
  chatBox.appendChild(messageElement);
  chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll to the bottom
}

// Function to get the bot's response using fetch
async function getBotResponse(userMessage) {
  appendMessage('user', userMessage);
  try {
    const response = await fetch('/chatbot', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prompt: userMessage })
    });
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    try {
      const data = await response.json();
      const botMessage = data.message;
      appendMessage('bot', botMessage);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      appendMessage('bot', "Sorry, I couldn't understand the response. Please try again.");
    }
  } catch (error) {
    console.error('Error fetching:', error);
    appendMessage('bot', "Sorry, the server is unavailable right now. Please try again later.");
  }
}

// Event listener for the Send button
sendButton.addEventListener('click', () => {
  const userMessage = userInput.value.trim();
  if (userMessage) {
    getBotResponse(userMessage);
    userInput.value = ''; // Clear input field
  }
});npm install express openai dotenvOPENAI_API_KEY=your_api_key// Import required packages
const express = require('express');
const { OpenAI } = require('openai');
require('dotenv').config(); // Load environment variables from .env

// Initialize express app
const app = express();
const port = process.env.PORT || 3000; // Use the environment port or default to 3000

// Initialize OpenAI client with the API key from the .env file
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,  // Your OpenAI key will be loaded from .env file
});

// Middleware to parse JSON request bodies
app.use(express.json());

// Define the route for chatbot interaction
app.post('/chatbot', async (req, res) => {
  const { prompt } = req.body; // Get user input from the request body

  try {
    // Call OpenAI API to get a response
    const completion = await openai.chat.completions.create({
      model: 'gpt-4', // You can change this to gpt-3.5-turbo or other models if needed
      messages: [{ role: 'user', content: prompt }],
    });

    // Get the AI response from the OpenAI API
    const botMessage = completion.choices[0].message.content;
    res.json({ message: botMessage }); // Send the bot's response back to the client

  } catch (error) {
    console.error('Error with OpenAI API:', error);
    res.status(500).send({ error: 'Failed to get a response from AI.' }); // Handle errors
  }
});

// Serve static files (your frontend files like HTML, CSS, JS)
app.use(express.static('public')); // Ensure you have a 'public' folder for your frontend files

// Start the server
app.listen(port, () => {
  console.log(Server running on port ${port}); // Log server running message
});